#!/bin/bash
script=`readlink -f $0`
script_dir=`dirname $(readlink -f $0)`
fire_home=$(readlink -f "$(dirname $script_dir)")
fire_wood="$fire_home/fire_wood"
utils="$fire_wood/utils"
shared="$fire_wood/shared/"
fs="$fire_wood/fire_fs"


mode="status"
encoded=`cat "$fs/shared/dat/private/urlCompliant.txt"`
apiKey=`cat "$shared/dat/private/key.txt"`

function startForging(){
	local forging=isForging
	if [[ $forging == "false" ]]
		"fire_forge status: staring forging....."
		echo `curl -k -s http://localhost:7733/api/v1/mining/start/$encoded\?api_key=$apiKey` 
	else
		echo "node is already forging"
	fi	
}


function isForging()){
	status=forgingStatus
	if [[ echo $status | grep "not forging" ]]; then
		echo "false"
	else
		echo "true"
	fi
}

function forgingStatus(){
	echo `curl -k -s http://localhost:7733/api/v1/mining/info/$encoded\?api_key=$apiKey`
)

#get arguments
# as long as there is at least one more argument, keep looping
while [[ $# -gt 0 ]]; do
    key="$1"
    case "$key" in
         -s|--start)
				if [[ "$mode" == "not_set" ]]; then
					mode="start"
				else
					echo "cannot set mode to start.mode is already set"
				fi		
				;;
			-i|--isforging)
				if [[ "$mode" == "not_set" ]]; then
					mode="isForging"
				else
					echo "cannot set mode to isforging. mode is already set"
				fi
				;;
			-s|--status)
				if [[ "$mode" == "not_set" ]]; then
					mode="status"
				else
					echo "cannot set mode to status. mode is already set"
				fi
				;;
	 		*)
        		# do whatever you want with extra options
        		echo "unknown option '$key'"
        		;;
    esac
    # shift after checking all the cases to get the next option
    shift
done

case "$mode" in
	"start")
		startForging
		;;
	"isForging")
		isForging
		;;
		
	"status")
		forgingStatus
		;;

	*)
		echo "invalid mode: $mode"
esac